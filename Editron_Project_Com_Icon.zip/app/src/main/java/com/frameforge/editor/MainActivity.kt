package com.frameforge.editor

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.media.MediaPlayer
import android.widget.VideoView
import android.widget.MediaController
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151922)
private val PanelLight = Color(0xFF1C2230)
private val Accent = Color(0xFF8B6CFF)
private val Accent2 = Color(0xFFB5A2FF)
private val Muted = Color(0xFF9BA4B5)
private val White = Color(0xFFF5F6FA)

private const val PREFS_NAME = "editron_local_data"
private const val PROJECTS_KEY = "projects_json"

private data class Project(
    val id: String,
    val name: String,
    val createdAt: Long,
    val color: Long,
    val fps: Int = 30,
    val ratio: String = "16:9",
    val widthPx: Int = 1920,
    val heightPx: Int = 1080
)

private fun loadProjects(context: Context): List<Project> {
    return try {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PROJECTS_KEY, "[]") ?: "[]"
        val json = JSONArray(raw)
        buildList {
            for (index in 0 until json.length()) {
                val item = json.optJSONObject(index) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                val name = item.optString("name").trim().takeIf { it.isNotBlank() } ?: continue
                add(
                    Project(
                        id = id,
                        name = name,
                        createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                        color = item.optLong("color", 0xFF8B6CFF),
                        fps = item.optInt("fps", 30).coerceIn(14, 60),
                        ratio = item.optString("ratio", "16:9"),
                        widthPx = item.optInt("widthPx", 1920).coerceIn(16, 8192),
                        heightPx = item.optInt("heightPx", 1080).coerceIn(16, 8192)
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveProjects(context: Context, projects: List<Project>) {
    val json = JSONArray()
    projects.forEach { project ->
        json.put(
            JSONObject().apply {
                put("id", project.id)
                put("name", project.name)
                put("createdAt", project.createdAt)
                put("color", project.color)
                put("fps", project.fps)
                put("ratio", project.ratio)
                put("widthPx", project.widthPx)
                put("heightPx", project.heightPx)
            }
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(PROJECTS_KEY, json.toString())
        .apply()
}

private fun projectDate(timestamp: Long): String = try {
    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
} catch (_: Exception) {
    "Data não disponível"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    secondary = Accent2,
                    background = Bg,
                    surface = Panel,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                EditronApp()
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }
}

@Composable
private fun EditronApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Início") }
    var showCreate by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var newFps by remember { mutableStateOf(30) }
    var newFpsMenu by remember { mutableStateOf(false) }
    var newRatio by remember { mutableStateOf("16:9") }
    var newRatioMenu by remember { mutableStateOf(false) }
    var newWidth by remember { mutableStateOf("1920") }
    var newHeight by remember { mutableStateOf("1080") }
    var projectToRename by remember { mutableStateOf<Project?>(null) }
    var renameText by remember { mutableStateOf("") }
    var projectToDelete by remember { mutableStateOf<Project?>(null) }
    var openedProjectId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Tudo pronto para começar.") }
    var projects by remember { mutableStateOf(loadProjects(context)) }

    fun updateProjects(updated: List<Project>) {
        projects = updated
        saveProjects(context, updated)
    }

    val importPreset = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Arquivo selecionado: ${uri.lastPathSegment ?: "arquivo"}. A leitura de presets ainda será implementada."
        }
    }
    val exportPreset = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write("""{"app":"Editron","formatVersion":1,"preset":{"name":"Meu preset","effects":[]},"note":"Modelo inicial; efeitos ainda não implementados"}""".toByteArray())
                } ?: throw IllegalStateException("Não foi possível abrir o arquivo")
                status = "Arquivo JSON de exemplo exportado."
            } catch (_: Exception) {
                status = "Não foi possível salvar o arquivo. Tente novamente."
            }
        }
    }

    val openedProject = projects.firstOrNull { it.id == openedProjectId }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Editron", color = White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text("VIDEO STUDIO  ·  BETA", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                if (openedProject == null && tab == "Início") {
                    IconButton(onClick = { projectName = ""; newFps = 30; newRatio = "16:9"; newWidth = "1920"; newHeight = "1080"; showCreate = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Criar projeto", tint = White, modifier = Modifier.size(29.dp))
                    }
                }
            }

            if (openedProject != null) {
                ProjectScreen(
                    project = openedProject,
                    onBack = { openedProjectId = null },
                    onRename = {
                        renameText = openedProject.name
                        projectToRename = openedProject
                    },
                    onDelete = { projectToDelete = openedProject },
                    onUpdateProject = { changed -> updateProjects(projects.map { if (it.id == changed.id) changed else it }) }
                )
            } else {
                when (tab) {
                    "Início" -> HomeScreen(
                        projects = projects,
                        onCreate = { projectName = ""; newFps = 30; newRatio = "16:9"; newWidth = "1920"; newHeight = "1080"; showCreate = true },
                        onOpenProject = { openedProjectId = it.id },
                        onRenameProject = {
                            renameText = it.name
                            projectToRename = it
                        },
                        onDeleteProject = { projectToDelete = it }
                    )
                    "Presets" -> PresetsScreen(
                        onImport = { importPreset.launch(arrayOf("*/*")) },
                        onExport = { exportPreset.launch("editron-preset.json") }
                    )
                    else -> AboutScreen()
                }
            }

            if (status != "Tudo pronto para começar.") {
                Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 7.dp))
            }
            Divider(color = Color(0xFF272D39))
            Row(
                modifier = Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem("Início", tab == "Início", Icons.Default.Home) { tab = "Início"; openedProjectId = null }
                NavItem("Presets", tab == "Presets", Icons.Default.Tune) { tab = "Presets"; openedProjectId = null }
                NavItem("Sobre", tab == "Sobre", Icons.Default.AutoAwesome) { tab = "Sobre"; openedProjectId = null }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = PanelLight,
            title = { Text("Novo projeto", color = White, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nome, FPS e formato do projeto", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Nome do projeto") },
                        singleLine = true
                    )
                    Text("TAXA DE QUADROS", color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Box {
                        OutlinedButton(onClick = { newFpsMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("$newFps FPS  ▾", color = White) }
                        DropdownMenu(expanded = newFpsMenu, onDismissRequest = { newFpsMenu = false }) {
                            (14..60).forEach { value -> DropdownMenuItem(text = { Text("$value FPS") }, onClick = { newFps = value; newFpsMenu = false }) }
                        }
                    }
                    Text("PROPORÇÃO", color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Box {
                        OutlinedButton(onClick = { newRatioMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("$newRatio  ▾", color = White) }
                        DropdownMenu(expanded = newRatioMenu, onDismissRequest = { newRatioMenu = false }) {
                            listOf("16:9", "9:16", "4:3", "3:4", "4:5", "1:1", "21:9", "Personalizada").forEach { value ->
                                DropdownMenuItem(text = { Text(value) }, onClick = {
                                    newRatio = value; newRatioMenu = false
                                    when (value) {
                                        "16:9" -> { newWidth = "1920"; newHeight = "1080" }
                                        "9:16" -> { newWidth = "1080"; newHeight = "1920" }
                                        "4:3" -> { newWidth = "1440"; newHeight = "1080" }
                                        "3:4" -> { newWidth = "1080"; newHeight = "1440" }
                                        "4:5" -> { newWidth = "1080"; newHeight = "1350" }
                                        "1:1" -> { newWidth = "1080"; newHeight = "1080" }
                                        "21:9" -> { newWidth = "2560"; newHeight = "1080" }
                                    }
                                })
                            }
                        }
                    }
                    if (newRatio == "Personalizada") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = newWidth, onValueChange = { newWidth = it.filter(Char::isDigit).take(5) }, modifier = Modifier.weight(1f), label = { Text("Largura px") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            OutlinedTextField(value = newHeight, onValueChange = { newHeight = it.filter(Char::isDigit).take(5) }, modifier = Modifier.weight(1f), label = { Text("Altura px") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                    }
                    Text("${newWidth.ifBlank { "0" }} × ${newHeight.ifBlank { "0" }} px", color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {
                Button(
                    enabled = projectName.trim().isNotEmpty() && newWidth.toIntOrNull() in 16..8192 && newHeight.toIntOrNull() in 16..8192,
                    onClick = {
                        val name = projectName.trim()
                        val colors = listOf(0xFF8B6CFF, 0xFF3D8F92, 0xFFE09B55, 0xFFDB668C)
                        val newProject = Project(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            createdAt = System.currentTimeMillis(),
                            color = colors[projects.size % colors.size],
                            fps = newFps,
                            ratio = newRatio,
                            widthPx = newWidth.toIntOrNull()?.coerceIn(16, 8192) ?: 1920,
                            heightPx = newHeight.toIntOrNull()?.coerceIn(16, 8192) ?: 1080
                        )
                        updateProjects(listOf(newProject) + projects)
                        projectName = ""
                        showCreate = false
                        status = "Projeto \"$name\" salvo neste dispositivo."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Criar") }
            },
            dismissButton = { OutlinedButton(onClick = { showCreate = false }) { Text("Cancelar") } }
        )
    }

    projectToRename?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToRename = null },
            containerColor = PanelLight,
            title = { Text("Renomear projeto", color = White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Novo nome") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    enabled = renameText.trim().isNotEmpty(),
                    onClick = {
                        val newName = renameText.trim()
                        updateProjects(projects.map { if (it.id == project.id) it.copy(name = newName) else it })
                        projectToRename = null
                        status = "Projeto renomeado para \"$newName\"."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Salvar") }
            },
            dismissButton = { OutlinedButton(onClick = { projectToRename = null }) { Text("Cancelar") } }
        )
    }

    projectToDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            containerColor = PanelLight,
            title = { Text("Excluir projeto?", color = White, fontWeight = FontWeight.Bold) },
            text = { Text("O projeto \"${project.name}\" será removido deste dispositivo. Essa ação não pode ser desfeita.", color = Muted) },
            confirmButton = {
                Button(
                    onClick = {
                        updateProjects(projects.filterNot { it.id == project.id })
                        if (openedProjectId == project.id) openedProjectId = null
                        projectToDelete = null
                        status = "Projeto excluído."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB84050))
                ) { Text("Excluir") }
            },
            dismissButton = { OutlinedButton(onClick = { projectToDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ColumnScope.HomeScreen(
    projects: List<Project>,
    onCreate: () -> Unit,
    onOpenProject: (Project) -> Unit,
    onRenameProject: (Project) -> Unit,
    onDeleteProject: (Project) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
                Text("Seu próximo projeto.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Crie, organize e prepare suas composições.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onCreate() },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Accent)
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NOVO PROJETO", color = Color.White.copy(alpha = .78f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Comece do zero", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Uma nova composição, pronta para ganhar forma.", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = White)
                            Text(" Criar projeto", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    Box(modifier = Modifier.size(62.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Meus projetos", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${projects.size}", color = Muted, fontSize = 12.sp)
            }
        }
        if (projects.isEmpty()) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = Accent2, modifier = Modifier.size(32.dp))
                        Text("Nenhum projeto ainda", color = White, fontWeight = FontWeight.SemiBold)
                        Text("Seus projetos salvos aparecerão aqui.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        items(projects, key = { it.id }) { project ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f).clickable { onOpenProject(project) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(50.dp).background(Color(project.color).copy(alpha = .22f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Color(project.color), modifier = Modifier.size(25.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(project.name, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Criado em ${projectDate(project.createdAt)}", color = Muted, fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = { onRenameProject(project) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Renomear ${project.name}", tint = Accent2, modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { onDeleteProject(project) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Excluir ${project.name}", tint = Color(0xFFFF7D89), modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = PanelLight)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Sobre o Editron", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Um editor de vídeo para Android em desenvolvimento.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("O gerenciamento de projetos está sendo desenvolvido antes das ferramentas reais de edição.", color = Accent2, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

private data class TimelineClip(val id: String, val uri: Uri, val label: String)

@Composable
private fun ColumnScope.ProjectScreen(
    project: Project,
    onBack: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onUpdateProject: (Project) -> Unit
) {
    val context = LocalContext.current
    var clips by remember(project.id) { mutableStateOf(emptyList<TimelineClip>()) }
    var selectedClipId by remember(project.id) { mutableStateOf<String?>(null) }
    var fps by remember(project.id) { mutableStateOf(project.fps) }
    var fpsMenu by remember { mutableStateOf(false) }
    val ratios = listOf("16:9", "9:16", "4:3", "3:4", "4:5", "1:1", "21:9", "Personalizada")
    var ratio by remember(project.id) { mutableStateOf(project.ratio) }
    var customWidth by remember(project.id) { mutableStateOf(project.widthPx.toString()) }
    var customHeight by remember(project.id) { mutableStateOf(project.heightPx.toString()) }
    var ratioMenu by remember { mutableStateOf(false) }
    var playheadSeconds by remember(project.id) { mutableStateOf(0f) }
    var status by remember(project.id) { mutableStateOf("Importe um vídeo para começar a edição.") }
    val selectedClip = clips.firstOrNull { it.id == selectedClipId } ?: clips.firstOrNull()

    val importVideos = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val newClips = uris.map { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                TimelineClip(UUID.randomUUID().toString(), uri, uri.lastPathSegment?.substringAfterLast('/')?.take(26) ?: "Vídeo")
            }
            clips = clips + newClips
            selectedClipId = newClips.first().id
            status = "${newClips.size} vídeo(s) adicionado(s) à timeline."
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Projetos", color = Accent2) }
            Column(modifier = Modifier.weight(1f)) {
                Text(project.name, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                Text("EDITOR MULTITRACK · BETA", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            IconButton(onClick = onRename) { Icon(Icons.Default.Edit, contentDescription = "Renomear projeto", tint = Accent2) }
        }

        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.Black)) {
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (selectedClip != null) {
                    key(selectedClip.id) {
                        AndroidView(
                            modifier = Modifier.fillMaxWidth().height(210.dp),
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    tag = selectedClip.uri.toString()
                                    val controller = MediaController(ctx)
                                    controller.setAnchorView(this)
                                    setMediaController(controller)
                                    setVideoURI(selectedClip.uri)
                                    setOnPreparedListener { mp: MediaPlayer ->
                                        mp.isLooping = false
                                        start()
                                        controller.show(2500)
                                    }
                                    setOnErrorListener { _, _, _ ->
                                        status = "Não foi possível reproduzir este vídeo. Tente outro arquivo MP4 ou MOV."
                                        true
                                    }
                                }
                            },
                            update = { view ->
                                if (view.tag != selectedClip.uri.toString()) {
                                    view.tag = selectedClip.uri.toString()
                                    view.setVideoURI(selectedClip.uri)
                                }
                            }
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("PRÉVIA DO PROJETO", color = Accent2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("${clips.size} clipe(s)", color = Muted, fontSize = 11.sp)
                    }
                } else {
                    Box(modifier = Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF090A0D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Accent2, modifier = Modifier.size(38.dp))
                            Text("Prévia do vídeo", color = White, fontWeight = FontWeight.SemiBold)
                            Text("Importe uma mídia para visualizar aqui", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { importVideos.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text(" Importar vídeo")
            }
            OutlinedButton(onClick = {
                clips = emptyList(); selectedClipId = null; playheadSeconds = 0f
                status = "Timeline limpa. Os arquivos originais não foram apagados."
            }, modifier = Modifier.weight(1f)) { Text("Limpar timeline") }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CONFIGURAÇÕES DO PROJETO", color = Accent2, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.1.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Taxa de quadros", color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("FPS do projeto", color = Muted, fontSize = 10.sp)
                    }
                    Box {
                        OutlinedButton(onClick = { fpsMenu = true }) { Text("$fps FPS ▾", color = White) }
                        DropdownMenu(expanded = fpsMenu, onDismissRequest = { fpsMenu = false }) {
                            (14..60).forEach { value -> DropdownMenuItem(text = { Text("$value FPS") }, onClick = { fps = value; fpsMenu = false; onUpdateProject(project.copy(fps = value)) }) }
                        }
                    }
                }
                Divider(color = Color(0xFF303746))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Proporção / resolução", color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Formato do quadro", color = Muted, fontSize = 10.sp)
                    }
                    Box {
                        OutlinedButton(onClick = { ratioMenu = true }) { Text("$ratio ▾", color = White) }
                        DropdownMenu(expanded = ratioMenu, onDismissRequest = { ratioMenu = false }) {
                            ratios.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { ratio = value; ratioMenu = false; onUpdateProject(project.copy(ratio = value)) }) }
                        }
                    }
                }
                if (ratio == "Personalizada") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = customWidth, onValueChange = { customWidth = it.filter(Char::isDigit).take(5); it.filter(Char::isDigit).take(5).toIntOrNull()?.let { n -> if (n in 16..8192) onUpdateProject(project.copy(widthPx = n, ratio = ratio)) } }, modifier = Modifier.weight(1f), label = { Text("Largura (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        OutlinedTextField(value = customHeight, onValueChange = { customHeight = it.filter(Char::isDigit).take(5); it.filter(Char::isDigit).take(5).toIntOrNull()?.let { n -> if (n in 16..8192) onUpdateProject(project.copy(heightPx = n, ratio = ratio)) } }, modifier = Modifier.weight(1f), label = { Text("Altura (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    }
                    Text("Resolução: ${customWidth.ifBlank { "0" }} × ${customHeight.ifBlank { "0" }} px", color = Accent2, fontSize = 11.sp)
                } else {
                    val dimensions = when (ratio) {
                        "16:9" -> "1920 × 1080 px"; "9:16" -> "1080 × 1920 px"; "4:3" -> "1440 × 1080 px";
                        "3:4" -> "1080 × 1440 px"; "4:5" -> "1080 × 1350 px"; "1:1" -> "1080 × 1080 px"; else -> "2560 × 1080 px"
                    }
                    Text("Resolução sugerida: $dimensions", color = Accent2, fontSize = 11.sp)
                }
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("TIMELINE", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${clips.size} mídia(s) · ${fps} FPS · $ratio", color = Muted, fontSize = 10.sp)
                    }
                    Text("${playheadSeconds.toInt()}s", color = Accent2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    (0..8).forEach { tick -> Text("${tick * 5}s", color = Muted, fontSize = 9.sp, modifier = Modifier.width(54.dp)) }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    Column(modifier = Modifier.width(54.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("VÍDEO", color = Accent2, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                        Text("ÁUDIO", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                    }
                    Column(modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(modifier = Modifier.height(66.dp).width((clips.size.coerceAtLeast(1) * 148).dp).background(Color(0xFF10141D), RoundedCornerShape(8.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            clips.forEachIndexed { index, clip ->
                                Column(modifier = Modifier.width(140.dp).fillMaxSize().background(if (clip.id == selectedClipId) Color(0xFF4D3A86) else Color(0xFF263144), RoundedCornerShape(6.dp)).clickable { selectedClipId = clip.id }.padding(7.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                    Text("▶  V${index + 1}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(clip.label, color = White, fontSize = 9.sp, maxLines = 1)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Clipe de vídeo", color = Color(0xFFD6CCFF), fontSize = 8.sp, modifier = Modifier.weight(1f))
                                        Text("×", color = Color(0xFFFF9AA5), fontSize = 16.sp, modifier = Modifier.clickable {
                                            clips = clips.filterNot { it.id == clip.id }
                                            if (selectedClipId == clip.id) selectedClipId = clips.firstOrNull()?.id
                                        })
                                    }
                                }
                            }
                            if (clips.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Importe um vídeo para começar", color = Muted, fontSize = 10.sp) }
                        }
                        Row(modifier = Modifier.height(42.dp).width((clips.size.coerceAtLeast(1) * 148).dp).background(Color(0xFF10141D), RoundedCornerShape(8.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            clips.forEachIndexed { index, clip ->
                                Box(modifier = Modifier.width(140.dp).fillMaxSize().background(Color(0xFF224C55), RoundedCornerShape(5.dp)).clickable { selectedClipId = clip.id }.padding(6.dp), contentAlignment = Alignment.CenterStart) {
                                    Text("〰 Áudio ${index + 1}", color = Color(0xFFB5F0E8), fontSize = 9.sp)
                                }
                            }
                            if (clips.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) { Text("Faixa de áudio aparecerá aqui", color = Muted, fontSize = 10.sp) }
                        }
                    }
                }
                if (clips.isNotEmpty()) Text("Selecione um clipe para pré-visualizar. A interface já separa as faixas de vídeo e áudio; corte, waveform real e exportação ainda serão etapas seguintes.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        Text(status, color = Accent2, fontSize = 11.sp, modifier = Modifier.padding(bottom = 14.dp))
    }
}

@Composable
private fun ColumnScope.PresetsScreen(onImport: () -> Unit, onExport: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(modifier = Modifier.padding(top = 8.dp)) {
            Text("Biblioteca de presets", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Importe e exporte configurações para reutilizar seus estilos.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
        PresetActionCard(
            title = "Importar preset",
            description = "Escolha um arquivo no armazenamento do celular.",
            icon = Icons.Default.ArrowDownward,
            buttonText = "Escolher arquivo",
            onClick = onImport
        )
        PresetActionCard(
            title = "Exportar preset",
            description = "Salve um arquivo JSON de exemplo.",
            icon = Icons.Default.ArrowUpward,
            buttonText = "Exportar arquivo",
            onClick = onExport
        )
        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Compatibilidade", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Nesta versão, importar apenas seleciona o arquivo e exportar cria um modelo JSON vazio. Presets .ffx e formatos de outros editores ainda não são interpretados.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun PresetActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(modifier = Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(42.dp).background(Accent.copy(alpha = .18f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = Accent2)
                }
                Spacer(Modifier.width(11.dp))
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Text(description, color = Muted, fontSize = 12.sp)
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent), modifier = Modifier.fillMaxWidth()) {
                Text(buttonText)
            }
        }
    }
}

@Composable
private fun ColumnScope.AboutScreen() {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Sobre o Editron", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Um estúdio criativo no seu celular.", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("O Editron está sendo desenvolvido como um editor de vídeo para Android, com projetos, timeline, animação, efeitos visuais e presets.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Divider(color = Color(0xFF303746))
                Text("Objetivo", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Construir uma ferramenta gratuita, com processamento local sempre que possível e uma interface pensada para telas Android.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Text("Editron em desenvolvimento: prévia e timeline multifaixa inicial. Cortes avançados, waveform e renderização ainda estão por implementar.", color = Accent2, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun NavItem(label: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(92.dp).clickable { onClick() }.padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Accent2 else Muted, modifier = Modifier.size(21.dp))
        Text(label, color = if (selected) White else Muted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        Box(modifier = Modifier.width(24.dp).height(3.dp).background(if (selected) Accent else Color.Transparent, RoundedCornerShape(3.dp)))
    }
}
