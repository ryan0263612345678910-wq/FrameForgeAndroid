package com.frameforge.editor

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151922)
private val PanelLight = Color(0xFF1C2230)
private val Accent = Color(0xFF8B6CFF)
private val Accent2 = Color(0xFFB5A2FF)
private val Muted = Color(0xFF9BA4B5)
private val White = Color(0xFFF5F6FA)

private const val PREFS_NAME = "editron_local_data"
private const val PROJECTS_KEY = "projects_json"

private data class Project(
    val id: String,
    val name: String,
    val createdAt: Long,
    val color: Long
)

private fun loadProjects(context: Context): List<Project> {
    return try {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PROJECTS_KEY, "[]") ?: "[]"
        val json = JSONArray(raw)
        buildList {
            for (index in 0 until json.length()) {
                val item = json.optJSONObject(index) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                val name = item.optString("name").trim().takeIf { it.isNotBlank() } ?: continue
                add(
                    Project(
                        id = id,
                        name = name,
                        createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                        color = item.optLong("color", 0xFF8B6CFF)
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveProjects(context: Context, projects: List<Project>) {
    val json = JSONArray()
    projects.forEach { project ->
        json.put(
            JSONObject().apply {
                put("id", project.id)
                put("name", project.name)
                put("createdAt", project.createdAt)
                put("color", project.color)
            }
        )
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(PROJECTS_KEY, json.toString())
        .apply()
}

private fun projectDate(timestamp: Long): String = try {
    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
} catch (_: Exception) {
    "Data não disponível"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    secondary = Accent2,
                    background = Bg,
                    surface = Panel,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                EditronApp()
            }
        }
    }
}

@Composable
private fun EditronApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Início") }
    var showCreate by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var projectToRename by remember { mutableStateOf<Project?>(null) }
    var renameText by remember { mutableStateOf("") }
    var projectToDelete by remember { mutableStateOf<Project?>(null) }
    var openedProjectId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Tudo pronto para começar.") }
    var projects by remember { mutableStateOf(loadProjects(context)) }

    fun updateProjects(updated: List<Project>) {
        projects = updated
        saveProjects(context, updated)
    }

    val importPreset = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Arquivo selecionado: ${uri.lastPathSegment ?: "arquivo"}. A leitura de presets ainda será implementada."
        }
    }
    val exportPreset = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write("""{"app":"Editron","formatVersion":1,"preset":{"name":"Meu preset","effects":[]},"note":"Modelo inicial; efeitos ainda não implementados"}""".toByteArray())
                } ?: throw IllegalStateException("Não foi possível abrir o arquivo")
                status = "Arquivo JSON de exemplo exportado."
            } catch (_: Exception) {
                status = "Não foi possível salvar o arquivo. Tente novamente."
            }
        }
    }

    val openedProject = projects.firstOrNull { it.id == openedProjectId }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Editron", color = White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text("VIDEO STUDIO  ·  BETA", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                if (openedProject == null && tab == "Início") {
                    IconButton(onClick = { projectName = ""; showCreate = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Criar projeto", tint = White, modifier = Modifier.size(29.dp))
                    }
                }
            }

            if (openedProject != null) {
                ProjectScreen(
                    project = openedProject,
                    onBack = { openedProjectId = null },
                    onRename = {
                        renameText = openedProject.name
                        projectToRename = openedProject
                    },
                    onDelete = { projectToDelete = openedProject }
                )
            } else {
                when (tab) {
                    "Início" -> HomeScreen(
                        projects = projects,
                        onCreate = { projectName = ""; showCreate = true },
                        onOpenProject = { openedProjectId = it.id },
                        onRenameProject = {
                            renameText = it.name
                            projectToRename = it
                        },
                        onDeleteProject = { projectToDelete = it }
                    )
                    "Presets" -> PresetsScreen(
                        onImport = { importPreset.launch(arrayOf("*/*")) },
                        onExport = { exportPreset.launch("editron-preset.json") }
                    )
                    else -> AboutScreen()
                }
            }

            Spacer(Modifier.weight(1f))
            if (status != "Tudo pronto para começar.") {
                Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 7.dp))
            }
            Divider(color = Color(0xFF272D39))
            Row(
                modifier = Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem("Início", tab == "Início", Icons.Default.Home) { tab = "Início"; openedProjectId = null }
                NavItem("Presets", tab == "Presets", Icons.Default.Tune) { tab = "Presets"; openedProjectId = null }
                NavItem("Sobre", tab == "Sobre", Icons.Default.AutoAwesome) { tab = "Sobre"; openedProjectId = null }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = PanelLight,
            title = { Text("Novo projeto", color = White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Escolha um nome para o projeto.", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Nome do projeto") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = projectName.trim().isNotEmpty(),
                    onClick = {
                        val name = projectName.trim()
                        val colors = listOf(0xFF8B6CFF, 0xFF3D8F92, 0xFFE09B55, 0xFFDB668C)
                        val newProject = Project(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            createdAt = System.currentTimeMillis(),
                            color = colors[projects.size % colors.size]
                        )
                        updateProjects(listOf(newProject) + projects)
                        projectName = ""
                        showCreate = false
                        status = "Projeto \"$name\" salvo neste dispositivo."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Criar") }
            },
            dismissButton = { OutlinedButton(onClick = { showCreate = false }) { Text("Cancelar") } }
        )
    }

    projectToRename?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToRename = null },
            containerColor = PanelLight,
            title = { Text("Renomear projeto", color = White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Novo nome") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    enabled = renameText.trim().isNotEmpty(),
                    onClick = {
                        val newName = renameText.trim()
                        updateProjects(projects.map { if (it.id == project.id) it.copy(name = newName) else it })
                        projectToRename = null
                        status = "Projeto renomeado para \"$newName\"."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Salvar") }
            },
            dismissButton = { OutlinedButton(onClick = { projectToRename = null }) { Text("Cancelar") } }
        )
    }

    projectToDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            containerColor = PanelLight,
            title = { Text("Excluir projeto?", color = White, fontWeight = FontWeight.Bold) },
            text = { Text("O projeto \"${project.name}\" será removido deste dispositivo. Essa ação não pode ser desfeita.", color = Muted) },
            confirmButton = {
                Button(
                    onClick = {
                        updateProjects(projects.filterNot { it.id == project.id })
                        if (openedProjectId == project.id) openedProjectId = null
                        projectToDelete = null
                        status = "Projeto excluído."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB84050))
                ) { Text("Excluir") }
            },
            dismissButton = { OutlinedButton(onClick = { projectToDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ColumnScope.HomeScreen(
    projects: List<Project>,
    onCreate: () -> Unit,
    onOpenProject: (Project) -> Unit,
    onRenameProject: (Project) -> Unit,
    onDeleteProject: (Project) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
                Text("Seu próximo projeto.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Crie, organize e prepare suas composições.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onCreate() },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Accent)
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NOVO PROJETO", color = Color.White.copy(alpha = .78f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Comece do zero", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Uma nova composição, pronta para ganhar forma.", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = White)
                            Text(" Criar projeto", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    Box(modifier = Modifier.size(62.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Meus projetos", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${projects.size}", color = Muted, fontSize = 12.sp)
            }
        }
        if (projects.isEmpty()) {
            item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = Accent2, modifier = Modifier.size(32.dp))
                        Text("Nenhum projeto ainda", color = White, fontWeight = FontWeight.SemiBold)
                        Text("Seus projetos salvos aparecerão aqui.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        items(projects, key = { it.id }) { project ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f).clickable { onOpenProject(project) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(50.dp).background(Color(project.color).copy(alpha = .22f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Color(project.color), modifier = Modifier.size(25.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(project.name, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Criado em ${projectDate(project.createdAt)}", color = Muted, fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = { onRenameProject(project) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Renomear ${project.name}", tint = Accent2, modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { onDeleteProject(project) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Excluir ${project.name}", tint = Color(0xFFFF7D89), modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = PanelLight)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Sobre o Editron", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Um editor de vídeo para Android em desenvolvimento.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("O gerenciamento de projetos está sendo desenvolvido antes das ferramentas reais de edição.", color = Accent2, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ProjectScreen(
    project: Project,
    onBack: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Voltar aos projetos", color = Accent2) }
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(modifier = Modifier.size(58.dp).background(Color(project.color).copy(alpha = .2f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color(project.color), modifier = Modifier.size(30.dp))
                }
                Text(project.name, color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Criado em ${projectDate(project.createdAt)}", color = Muted, fontSize = 12.sp)
                Divider(color = Color(0xFF303746))
                Text("Este projeto está salvo neste dispositivo.", color = White, fontSize = 14.sp)
                Text("A timeline, a importação de mídia e a edição de vídeo ainda serão implementadas. Esta tela confirma a abertura do projeto, mas ainda não é o editor de vídeo.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRename, modifier = Modifier.weight(1f)) { Text("Renomear") }
                    Button(
                        onClick = onDelete,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB84050))
                    ) { Text("Excluir") }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.PresetsScreen(onImport: () -> Unit, onExport: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(modifier = Modifier.padding(top = 8.dp)) {
            Text("Biblioteca de presets", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Importe e exporte configurações para reutilizar seus estilos.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
        PresetActionCard(
            title = "Importar preset",
            description = "Escolha um arquivo no armazenamento do celular.",
            icon = Icons.Default.ArrowDownward,
            buttonText = "Escolher arquivo",
            onClick = onImport
        )
        PresetActionCard(
            title = "Exportar preset",
            description = "Salve um arquivo JSON de exemplo.",
            icon = Icons.Default.ArrowUpward,
            buttonText = "Exportar arquivo",
            onClick = onExport
        )
        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Compatibilidade", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Nesta versão, importar apenas seleciona o arquivo e exportar cria um modelo JSON vazio. Presets .ffx e formatos de outros editores ainda não são interpretados.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun PresetActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(modifier = Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(42.dp).background(Accent.copy(alpha = .18f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = Accent2)
                }
                Spacer(Modifier.width(11.dp))
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Text(description, color = Muted, fontSize = 12.sp)
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent), modifier = Modifier.fillMaxWidth()) {
                Text(buttonText)
            }
        }
    }
}

@Composable
private fun ColumnScope.AboutScreen() {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Sobre o Editron", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Um estúdio criativo no seu celular.", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("O Editron está sendo desenvolvido como um editor de vídeo para Android, com projetos, timeline, animação, efeitos visuais e presets.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Divider(color = Color(0xFF303746))
                Text("Objetivo", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Construir uma ferramenta gratuita, com processamento local sempre que possível e uma interface pensada para telas Android.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Text("Estado atual: gerenciamento local de projetos em implementação. Timeline, renderização e compatibilidade avançada de presets ainda estão por implementar.", color = Accent2, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun NavItem(label: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(92.dp).clickable { onClick() }.padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Accent2 else Muted, modifier = Modifier.size(21.dp))
        Text(label, color = if (selected) White else Muted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        Box(modifier = Modifier.width(24.dp).height(3.dp).background(if (selected) Accent else Color.Transparent, RoundedCornerShape(3.dp)))
    }
}
