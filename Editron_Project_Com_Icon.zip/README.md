# Editron — interface de transformação e proporção

Esta versão reorganiza os controles do editor para uma interface inspirada na referência enviada.

## O que mudou
- Posição X e Y editáveis por campos numéricos (sem sliders).
- Escala editável em porcentagem, com botões +/− para ajustes rápidos.
- Rotação editável em graus, com botões +/−.
- Valores atualizam a transformação da prévia enquanto são alterados.
- Botão para restaurar X=0, Y=0, escala=100% e rotação=0°.
- O quadro de prévia muda de formato conforme a proporção selecionada no projeto (16:9, 9:16, 4:3, 3:4, 4:5, 1:1, 21:9 ou personalizada).
- Controle de velocidade experimental sem slider, usando botões +/−.

## Limitações conhecidas
- A transformação é aplicada à prévia do clipe selecionado; ainda não existe renderização/exportação final com esses ajustes.
- Os valores de transformação ainda não são salvos individualmente por clipe nem persistem ao fechar e reabrir o projeto.
- Posição usa pixels da tela da prévia, então os valores podem parecer diferentes em aparelhos de tamanhos diferentes.
- Keyframes ainda são registros simples: não interpolam o movimento entre quadros.
- Time Remap, frame blending, motion blur, rastreamento, IA e upscale ainda não processam o vídeo de verdade.
- A compilação precisa ser validada pelo workflow do GitHub Actions.

## Como compilar
Use o workflow já existente no repositório. Substitua o conteúdo de `Editron_Project_Com_Icon.zip` pelo conteúdo deste projeto, mantendo o nome do ZIP que o workflow espera. Faça commit e aguarde o GitHub Actions terminar. Se a compilação ficar verde, baixe o artefato `Editron-APK`.
