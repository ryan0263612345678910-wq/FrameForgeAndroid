# Editron Android

Editor de vídeo Android em desenvolvimento.

## Esta versão
- Prévia de vídeo com controles de reprodução do Android MediaController.
- Importação de múltiplos vídeos por seletor de documentos.
- Timeline visual inicial com faixas identificadas como vídeo e áudio.
- Configuração de FPS (14–60), proporções predefinidas e resolução personalizada.
- Nome, FPS, proporção e resolução escolhidos no diálogo de criação do projeto.
- Campos de largura e altura com teclado numérico.
- Configurações de projeto salvas localmente.

## Limitações conhecidas
A timeline é uma interface inicial: ainda não há edição por corte/trim, waveform real, mixagem de áudio, transições ou exportação/renderização final. O FPS e a resolução são metadados do projeto nesta fase; não alteram o arquivo original nem garantem a taxa de quadros do vídeo exportado.

## Build
O repositório usa Gradle Kotlin DSL e o workflow GitHub Actions do projeto para compilar o APK.
