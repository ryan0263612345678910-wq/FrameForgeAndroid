# Editron — Transformação e recursos experimentais

Esta versão acrescenta controles iniciais de transformação para a prévia: posição X/Y, escala, rotação e alinhamento aproximado; botão para registrar valores como keyframes; controle visual de velocidade/time remap; e opções de interface para frame blending, motion blur, wiggle, motion tracking, efeitos experimentais, assistente de IA e upscale tipo Topaz.

## Limitações importantes
- Os keyframes são registros de valores na sessão atual; interpolação e curvas/gráficos de animação ainda não estão implementados.
- O controle de time remap ajusta um valor de velocidade na interface, mas ainda não altera a reprodução/renderização do arquivo.
- Frame blending, motion blur, wiggle, motion tracker, efeitos por IA e upscale 4K são opções experimentais de interface, não processamento real do vídeo nesta versão.
- A IA de transferência de estilo/preservação de rosto e o upscale semelhante ao Topaz exigem modelos e um pipeline de processamento de vídeo que não estão incluídos.
- A timeline apresenta a faixa de vídeo; não cria uma faixa de áudio separada.
- A exportação/renderização final ainda não foi implementada.

O projeto deve ser compilado pelo GitHub Actions antes de instalar. Não foi possível executar uma compilação Android local neste ambiente.


## Controles de transformação (experimental)
Posição X/Y, escala e rotação agora usam sliders com valores visíveis e botão de restauração. A transformação afeta a visualização do clipe selecionado. A implementação ainda é básica: os valores não são salvos permanentemente no projeto nem associados individualmente a cada clipe, e keyframes ainda não interpolam movimento. O APK precisa ser compilado e testado pelo GitHub Actions.
