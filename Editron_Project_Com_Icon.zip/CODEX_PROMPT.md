# Prompt inicial para o Codex

Copie e cole o texto abaixo na primeira tarefa do Codex depois de conectar este repositório.

---

Você é o engenheiro principal do FrameForge, um editor Android nativo de composição de vídeo, local-first, gratuito e inspirado em ferramentas profissionais de motion graphics.

CONTEXTO:
- O dispositivo de teste é um Redmi A5.
- O proprietário só tem celular, sem computador.
- O projeto deve compilar por CI na nuvem e entregar um APK Android instalável.
- O starter atual é somente uma interface protótipo; não afirme que já edita/exporta vídeo.
- Não adicione serviços pagos nem exija chaves de API.
- Não copie código proprietário nem tente carregar plugins binários do After Effects.

PRIMEIRA TAREFA:
1. Inspecione todos os arquivos.
2. Verifique a compilação com `gradle assembleDebug`.
3. Corrija erros de compilação e execute os testes disponíveis.
4. Preserve uma arquitetura simples, modular e compatível com Android.
5. Acrescente um documento `ROADMAP.md` com fases pequenas e critérios verificáveis.
6. Não implemente tudo de uma vez. Não adicione dependências desnecessárias.
7. Confirme o caminho do APK gerado e liste as limitações restantes.

ARQUITETURA DESEJADA:
- Kotlin + Jetpack Compose para interface.
- Modelo de composição independente da UI.
- Timeline com camadas, clipes e keyframes.
- Importação de mídia via Android Storage Access Framework.
- Motor de preview e renderização local, introduzido gradualmente.
- Efeitos implementados pelo próprio projeto, com parâmetros e keyframes.
- Assistente inicial de IA baseado em regras e presets, funcionando offline.
- Sistema versionado de presets/plugins próprios.
- Formato de projeto JSON versionado, com migrações.
- Testes unitários para modelo, timeline, presets e serialização.

REGRAS TÉCNICAS:
- O preview e a exportação devem compartilhar as definições dos efeitos sempre que possível.
- Evite decodificar o vídeo inteiro em RAM; use processamento por frames e limites de cache.
- Mostre mensagens claras quando um efeito não for suportado.
- Implemente autosave seguro e recuperação após encerramento inesperado.
- Inclua acessibilidade básica e controles utilizáveis em tela pequena.
- Mantenha o app funcional em aparelhos modestos; recursos avançados devem ter fallback.
- Antes de adicionar FFmpeg ou bibliotecas de renderização, compare licenças, tamanho do APK e compatibilidade.
- Arquivos `.ffx` devem ser tratados como formato proprietário/fechado: não alegue compatibilidade integral. Primeiro implemente detecção e mensagem explicativa; depois avalie importação parcial legal e tecnicamente documentada, ou presets nativos equivalentes.

PRIORIDADE IMEDIATA:
Faça o projeto compilar e configure o workflow GitHub Actions para gerar `app-debug.apk`. Não avance para efeitos complexos antes de uma compilação verde.
