# Editron — orientação do projeto

Manter o app Android em Kotlin + Jetpack Compose, tema escuro e acentos roxos do Editron.

Prioridades atuais:
1. Garantir que a prévia de vídeo abra a URI selecionada, apresente controles de reprodução e informe falhas de mídia.
2. Manter a importação de vários vídeos e a seleção de clipes na timeline.
3. Mostrar uma timeline visual com faixas separadas e clipes selecionáveis.
4. Configurar nome, FPS entre 14 e 60, proporção e dimensões personalizadas no mesmo diálogo de criação de projeto.
5. Usar teclado numérico para largura e altura em pixels.
6. Persistir as configurações do projeto sem quebrar projetos antigos salvos localmente.

Não declarar que existe edição/exportação profissional enquanto corte, áudio, efeitos e renderização não estiverem implementados e testados. Preservar compatibilidade com projetos salvos anteriormente.
