package com.frameforge.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101216)
private val Panel = Color(0xFF1A1E25)
private val Accent = Color(0xFF7C5CFF)
private val Muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent,
                background = Bg,
                surface = Panel
            )) {
                FrameForgeHome()
            }
        }
    }
}

@Composable
private fun FrameForgeHome() {
    var selectedTab by remember { mutableStateOf("Efeitos") }
    var message by remember { mutableStateOf("Projeto vazio · protótipo de interface") }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("FRAMEFORGE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                    Text("Editor de composição · protótipo 0.1", color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = { message = "Salvar projeto será implementado na próxima fase." }) {
                    Icon(Icons.Default.Save, contentDescription = "Salvar", tint = Color.White)
                }
                IconButton(onClick = { message = "Importação de mídia será implementada na próxima fase." }) {
                    Icon(Icons.Default.FileOpen, contentDescription = "Importar mídia", tint = Color.White)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF08090C)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().weight(0.9f)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PREVIEW", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Sua composição aparecerá aqui", color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Importação e renderização ainda não implementadas", color = Muted, fontSize = 10.sp)
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { message = "Reprodução será ligada ao motor de vídeo futuramente." }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir", tint = Color.White)
                }
                IconButton(onClick = { message = "Ferramenta de corte será implementada com a timeline funcional." }) {
                    Icon(Icons.Default.ContentCut, contentDescription = "Cortar", tint = Color.White)
                }
                Text("00:00:00:00", color = Color.White, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text("30 FPS", color = Muted, fontSize = 11.sp)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TIMELINE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { message = "Adicionar camada será implementado na próxima fase." }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Add, contentDescription = "Adicionar camada", tint = Color.White)
                        }
                    }
                    TimelineTrack("VÍDEO 1", listOf(Color(0xFF5B4AC7), Color(0xFF8068F5), Color(0xFF5B4AC7)))
                    TimelineTrack("TEXTO", listOf(Color(0xFF267B78), Color(0xFF267B78)))
                    TimelineTrack("ÁUDIO", listOf(Color(0xFF98632D), Color(0xFF98632D), Color(0xFF98632D)))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                listOf("Camadas", "Efeitos", "Animação", "Máscaras", "3D", "IA").forEach { tab ->
                    Button(onClick = { selectedTab = tab }, shape = RoundedCornerShape(9.dp)) {
                        Text(tab, fontSize = 11.sp)
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(selectedTab.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        when (selectedTab) {
                            "IA" -> "Assistente local: presets e sugestões de efeitos (em planejamento)."
                            "3D" -> "Planos 3D, câmera e profundidade (fase futura)."
                            "Animação" -> "Keyframes, easing e curvas de movimento (fase futura)."
                            "Máscaras" -> "Máscaras, recorte e track mattes (fase futura)."
                            "Camadas" -> "Organização de camadas e pré-composições (fase futura)."
                            else -> "Glow · Blur · Shake · RGB Split · Color grading (a implementar)."
                        },
                        color = Muted,
                        fontSize = 11.sp
                    )
                }
            }

            Text(message, color = Muted, fontSize = 10.sp)
            Text("Aviso: interface inicial. Ainda não edita nem exporta vídeos.", color = Color(0xFFFFC857), fontSize = 10.sp)
        }
    }
}

@Composable
private fun TimelineTrack(name: String, colors: List<Color>) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(name, color = Muted, fontSize = 9.sp, modifier = Modifier.width(54.dp))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            colors.forEachIndexed { index, color ->
                Box(
                    modifier = Modifier
                        .weight(if (index == 1) 1.4f else 1f)
                        .height(24.dp)
                        .background(color, RoundedCornerShape(5.dp))
                )
            }
        }
    }
}
