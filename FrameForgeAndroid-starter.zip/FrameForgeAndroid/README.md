# FrameForge Android (protótipo inicial)

FrameForge é um nome provisório para um editor Android nativo, local e gratuito, inspirado em editores profissionais de composição.

## Estado atual
Este é o esqueleto inicial da interface, não um editor de vídeo completo. A timeline, os controles e os efeitos listados na interface são protótipos visuais; importação, renderização e efeitos reais serão implementados por etapas.

## Requisitos de build
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Build
Em um ambiente com Android SDK e Gradle instalados:

```bash
gradle assembleDebug
```

O APK de depuração deverá ficar em:
`app/build/outputs/apk/debug/app-debug.apk`

## Próximas tarefas
1. Fazer o projeto compilar.
2. Separar modelo de projeto, timeline e interface.
3. Adicionar importação de mídia usando o seletor de arquivos Android.
4. Implementar preview de vídeo e transporte.
5. Implementar exportação local.
6. Adicionar efeitos nativos gradualmente.
7. Criar o assistente local baseado em regras/presets.
8. Investigar suporte parcial a presets `.ffx`.

## Importante sobre `.ffx`
`.ffx` é um formato de preset do After Effects. Não é um formato aberto e genérico de efeitos Android. Não prometa compatibilidade direta. O app deverá futuramente:
- identificar arquivos `.ffx`;
- informar que a compatibilidade é experimental;
- importar apenas os dados que forem compreendidos por um conversor legal e tecnicamente viável;
- oferecer presets nativos equivalentes como alternativa.
Não copie código, efeitos ou recursos proprietários dos plugins comerciais.

## Licenças
Confira as licenças de todas as dependências antes de distribuir o app. Este repositório inicial não inclui FFmpeg nem bibliotecas de terceiros além das dependências Android/Compose.
