package com.frameforge.editor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151922)
private val PanelLight = Color(0xFF1C2230)
private val Accent = Color(0xFF8B6CFF)
private val Accent2 = Color(0xFFB5A2FF)
private val Muted = Color(0xFF9BA4B5)
private val White = Color(0xFFF5F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, secondary = Accent2,
                background = Bg, surface = Panel, onBackground = White, onSurface = White
            )) {
                FrameForgeApp()
            }
        }
    }
}

private data class Project(val name: String, val subtitle: String, val color: Color)

@Composable
private fun FrameForgeApp() {
    var tab by remember { mutableStateOf("Início") }
    var showCreate by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Tudo pronto para começar.") }
    var projects by remember {
        mutableStateOf(listOf(
            Project("Meu primeiro projeto", "Projeto de demonstração · ainda vazio", Accent),
            Project("Composição 01", "Projeto de exemplo · ainda vazio", Color(0xFF3D8F92))
        ))
    }

    val importPreset = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) status = "Preset selecionado: ${uri.lastPathSegment ?: "arquivo"}. A leitura de formatos de preset será implementada numa próxima fase."
    }
    val exportPreset = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write("""{"app":"FrameForge","formatVersion":1,"preset":{"name":"Meu preset","effects":[]},"note":"Modelo inicial; efeitos ainda não implementados"}""".toByteArray())
                }
                status = "Arquivo de preset de exemplo exportado."
            } catch (_: Exception) {
                status = "Não foi possível salvar o arquivo. Tente novamente."
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("FrameForge", color = White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text("VIDEO STUDIO  ·  BETA", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                IconButton(onClick = { showCreate = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Criar projeto", tint = White, modifier = Modifier.size(29.dp))
                }
            }

            when (tab) {
                "Início" -> HomeScreen(
                    projects = projects,
                    onCreate = { showCreate = true },
                    onOpenProject = { project -> status = "Projeto selecionado: ${project.name}. O editor funcional será desenvolvido na próxima etapa." }
                )
                "Presets" -> PresetsScreen(
                    onImport = { importPreset.launch(arrayOf("*/*")) },
                    onExport = { exportPreset.launch("frameforge-preset.json") },
                    status = status
                )
                else -> AboutScreen()
            }

            Spacer(Modifier.weight(1f))
            if (status != "Tudo pronto para começar.") {
                Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 7.dp))
            }
            Divider(color = Color(0xFF272D39))
            Row(
                modifier = Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem("Início", tab == "Início", Icons.Default.Home) { tab = "Início" }
                NavItem("Presets", tab == "Presets", Icons.Default.Tune) { tab = "Presets" }
                NavItem("Sobre", tab == "Sobre", Icons.Default.AutoAwesome) { tab = "Sobre" }
            }
        }
    }

    if (showCreate) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = PanelLight,
            title = { Text("Novo projeto", color = White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dê um nome para sua nova composição.", color = Muted, fontSize = 13.sp)
                    androidx.compose.material3.OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Nome do projeto") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val name = projectName.trim().ifBlank { "Projeto ${projects.size + 1}" }
                    projects = listOf(Project(name, "Criado agora · projeto vazio", Accent)) + projects
                    projectName = ""
                    showCreate = false
                    status = "Projeto \"$name\" criado na lista. Ainda não há edição ou salvamento de projetos."
                }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Criar") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCreate = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun HomeScreen(
    projects: List<Project>,
    onCreate: () -> Unit,
    onOpenProject: (Project) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
                Text("Seu próximo projeto.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Crie, organize e prepare suas composições.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onCreate() },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Accent)
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NOVO PROJETO", color = Color.White.copy(alpha = .78f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Comece do zero", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Uma nova composição, pronta para ganhar forma.", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = White)
                            Text(" Criar projeto", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    Box(modifier = Modifier.size(62.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Projetos recentes", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${projects.size}", color = Muted, fontSize = 12.sp)
            }
        }
        items(projects) { project ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpenProject(project) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(54.dp).background(project.color.copy(alpha = .22f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = project.color, modifier = Modifier.size(26.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(project.name, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(project.subtitle, color = Muted, fontSize = 11.sp)
                    }
                    Text("›", color = Muted, fontSize = 25.sp)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = PanelLight)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("O que é o FrameForge?", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Um editor de composição para Android, pensado para combinar vídeo, efeitos, animação e presets num só fluxo de trabalho.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("Esta versão é uma base inicial: ainda estamos construindo as ferramentas reais de edição.", color = Accent2, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun PresetsScreen(onImport: () -> Unit, onExport: () -> Unit, status: String) {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(modifier = Modifier.padding(top = 8.dp)) {
            Text("Biblioteca de presets", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Importe e exporte configurações para reutilizar seus estilos.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
        PresetActionCard(
            title = "Importar preset",
            description = "Escolha um arquivo no armazenamento do celular.",
            icon = Icons.Default.ArrowDownward,
            buttonText = "Escolher arquivo",
            onClick = onImport
        )
        PresetActionCard(
            title = "Exportar preset",
            description = "Salve um arquivo JSON de exemplo para compartilhar ou guardar.",
            icon = Icons.Default.ArrowUpward,
            buttonText = "Exportar arquivo",
            onClick = onExport
        )
        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Compatibilidade", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Nesta versão, importar apenas seleciona o arquivo e exportar cria um modelo JSON vazio. Presets .ffx e formatos de outros editores ainda não são interpretados.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun PresetActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(modifier = Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(42.dp).background(Accent.copy(alpha = .18f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = Accent2)
                }
                Spacer(Modifier.width(11.dp))
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Text(description, color = Muted, fontSize = 12.sp)
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent), modifier = Modifier.fillMaxWidth()) {
                Text(buttonText)
            }
        }
    }
}

@Composable
private fun AboutScreen() {
    Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Sobre o FrameForge", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Um estúdio criativo no seu celular.", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("O FrameForge está sendo desenvolvido como um editor de composição inspirado em fluxos profissionais: camadas, animação, efeitos visuais, máscaras, ferramentas assistidas por IA e presets.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Divider(color = Color(0xFF303746))
                Text("Objetivo", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Construir uma ferramenta gratuita, com processamento local sempre que possível e uma interface pensada para telas Android.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Text("Estado atual: protótipo de interface. Edição de vídeo, renderização e compatibilidade avançada de presets ainda estão por implementar.", color = Accent2, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun NavItem(label: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(92.dp).clickable { onClick() }.padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Accent2 else Muted, modifier = Modifier.size(21.dp))
        Text(label, color = if (selected) White else Muted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        Box(modifier = Modifier.width(24.dp).height(3.dp).background(if (selected) Accent else Color.Transparent, RoundedCornerShape(3.dp)))
    }
}
